import flet as ft
import random

def main(page: ft.Page):

    def rollDice(e):
        value = random.randint(1, 6)
        rollNumber.value = str(value)
        diceImage.height = diceImage.width = 300
        match value:
            case 1:
                diceImage.src = "face1.png"
            case 2:
                diceImage.src = "face2.png"
            case 3:
                diceImage.src = "face3.png"
            case 4:
                diceImage.src = "face4.png"
            case 5:
                diceImage.src = "face5.png"
            case 6:
                diceImage.src = "face6.png"
        page.update()


    global diceImage, rollNumber
    page.horizontal_alignment = "CENTER"
    page.vertical_alignment = "CENTER"

    diceImage = ft.Image(src="dice.png")
    rollNumber = ft.Text(value="No roll", size=50)
    rollButton = ft.ElevatedButton(text="Roll", height=50, width=200, on_click=rollDice)
    page.add(diceImage, rollNumber, rollButton)

ft.app(target=main)
